import { useState } from 'react'
import { Loader2 } from 'lucide-react'
import { account } from '../../lib/appwrite'

export default function GoogleAuthButton({ label = 'Continue with Google' }) {
  const [loading, setLoading] = useState(false)

  const handleGoogleAuth = async () => {
    setLoading(true)
    const origin = typeof window !== 'undefined' ? window.location.origin : 'http://localhost:5174'
    const redirectSuccess = `${origin}/oauth/callback`
    const redirectFailure = `${origin}/login`

    try {
      // Use createOAuth2Token so Appwrite returns userId & secret in URL params
      // This avoids 3rd-party cookie blocking on localhost / cross-domain
      if (typeof account.createOAuth2Token === 'function') {
        await account.createOAuth2Token('google', redirectSuccess, redirectFailure)
      } else {
        await account.createOAuth2Session('google', redirectSuccess, redirectFailure)
      }
    } catch (err) {
      console.warn('createOAuth2Token fallback to createOAuth2Session:', err)
      try {
        await account.createOAuth2Session('google', redirectSuccess, redirectFailure)
      } catch (fallbackErr) {
        console.error('OAuth initiation failed:', fallbackErr)
        setLoading(false)
      }
    }
  }

  return (
    <button
      type="button"
      onClick={handleGoogleAuth}
      disabled={loading}
      className="w-full flex items-center justify-center gap-3 px-4 py-3 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-850 hover:bg-zinc-50 dark:hover:bg-zinc-800 text-zinc-800 dark:text-zinc-200 font-bold text-sm transition-all shadow-xs disabled:opacity-50"
    >
      {loading ? (
        <Loader2 className="w-4 h-4 animate-spin text-orange-500" />
      ) : (
        <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
          <path
            fill="#EA4335"
            d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
          />
          <path
            fill="#4285F4"
            d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
          />
          <path
            fill="#FBBC05"
            d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
          />
          <path
            fill="#34A853"
            d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
          />
          <path fill="none" d="M0 0h48v48H0z" />
        </svg>
      )}
      <span>{label}</span>
    </button>
  )
}
